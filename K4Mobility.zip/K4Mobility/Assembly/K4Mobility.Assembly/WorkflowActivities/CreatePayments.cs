﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class CreatePayments : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("Contact")]
        [ReferenceTarget("contact")]
        public InArgument<EntityReference> Contact { get; set; }
        [RequiredArgument]
        [Input("Order")]
        [ReferenceTarget("salesorder")]
        public InArgument<EntityReference> Order { get; set; }

        [RequiredArgument]
        [Input("StartDate")]
        public InArgument<DateTime> StartDate { get; set; }

        [Input("SubcriptionType")]
        [RequiredArgument]
        public InArgument<string> SubcriptionType { get; set; }


        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Contact.Get<EntityReference>(executionContext) != null && StartDate.Get<DateTime>(executionContext) != null
                    && SubcriptionType.Get<string>(executionContext) != null
                    )
                {
                    Money amount = new Money();
                    if (Order.Get<EntityReference>(executionContext) != null)
                    {
                        EntityReference entity = Order.Get<EntityReference>(executionContext);
                        tracingService.Trace(entity.Id.ToString());
                        amount = getExdAmount(service, entity.Id.ToString());
                        tracingService.Trace(amount.Value.ToString());
                        
                    }
                 
                    if (SubcriptionType.Get<string>(executionContext) == "Monthly")
                    {
                        int paymentCount = 12 - StartDate.Get<DateTime>(executionContext).Month;

                        for (int x = 1; x <= paymentCount; x++)
                        {
                            Entity payment = new Entity("k4_paymentinformation");
                            payment.Attributes["k4_contact"] = Contact.Get<EntityReference>(executionContext);
                            payment.Attributes["k4_name"] = "Payment on - " + StartDate.Get<DateTime>(executionContext).AddMonths(x);
                            payment.Attributes["k4_paymentdate"] = StartDate.Get<DateTime>(executionContext).AddMonths(x).ToUniversalTime();
                            payment.Attributes["k4_amount"] = amount;
                            

                            service.Create(payment);

                        }
                    }
                    if (SubcriptionType.Get<string>(executionContext) == "Yearly")
                    {
                        Entity payment = new Entity("k4_paymentinformation");
                        payment.Attributes["k4_contact"] = Contact.Get<EntityReference>(executionContext);
                        payment.Attributes["k4_name"] = "Payment on - " + StartDate.Get<DateTime>(executionContext).AddYears(1);
                        payment.Attributes["k4_paymentdate"] = StartDate.Get<DateTime>(executionContext).AddYears(1).ToUniversalTime();
                        payment.Attributes["k4_amount"] = amount;
                        service.Create(payment);
                    }
                    }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in CreatePayments workflow: " + ex.Message.ToString());
            }

        }




        Money getExdAmount(IOrganizationService service, string salesorderid)
        {
            decimal damt = 0;
            Money amt =new Money(damt);
            string fetch = "<fetch top='1' >" +
"  <entity name='salesorderdetail' >" +
"    <attribute name='extendedamount' />" +
"    <attribute name='salesorderdetailid' />" +
"    <filter type='and' >" +
"      <condition attribute='salesorderid' operator='eq' value='{" + salesorderid + "}' />" +
"    </filter>" +
"    <link-entity name='product' from='productid' to='productid' link-type='inner' alias='a_5132182cc136e911a95a000d3af2c9f1' >" +
"      <filter type='and' >" +
"        <condition attribute='productstructure' operator='eq' value='3' />" +
"      </filter>" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";

            var collection = service.RetrieveMultiple(new FetchExpression(fetch));
            if (collection.Entities.Count > 0)
            {
                if (collection.Entities[0].Attributes.Contains("extendedamount"))
                {
                    amt = (Microsoft.Xrm.Sdk.Money)collection.Entities[0].Attributes["extendedamount"];
                        
                }

            }
            return amt;
        }
        #endregion
    }
}
