﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class ShareLead: CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("User")]
        [ReferenceTarget("systemuser")]
        public InArgument<EntityReference> User { get; set; }
        [RequiredArgument]
        [Input("Team")]
        [ReferenceTarget("team")]
        public InArgument<EntityReference> Team { get; set; }

        [Input("Lead")]
        [RequiredArgument]
        [ReferenceTarget("lead")]
        public InArgument<EntityReference> Lead { get; set; }


        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                if (Lead.Get<EntityReference>(executionContext) != null && User.Get<EntityReference>(executionContext) != null)
                {
                    traceMessage += ("\n Check lead access ");
                    RetrievePrincipalAccessResponse principalAccessRes=RetrieveAndDisplayPrincipalAccess(Lead.Get<EntityReference>(executionContext), User.Get<EntityReference>(executionContext), service);
                    if(principalAccessRes.AccessRights!= AccessRights.ReadAccess)
                    {
                        traceMessage += ("\n Grant the user read access to the lead.");
                        var grantAccessRequest1 = new GrantAccessRequest
                        {
                            PrincipalAccess = new PrincipalAccess
                            {
                                AccessMask = AccessRights.ReadAccess,
                                Principal = User.Get<EntityReference>(executionContext)
                            },
                            Target = Lead.Get<EntityReference>(executionContext)
                        };
                        service.Execute(grantAccessRequest1);
                    }
                }
                if (Lead.Get<EntityReference>(executionContext) != null && Team.Get<EntityReference>(executionContext) != null)
                {
                    traceMessage += ("\n Check lead access ");
                    RetrievePrincipalAccessResponse principalAccessRes = RetrieveAndDisplayPrincipalAccess(Lead.Get<EntityReference>(executionContext), Team.Get<EntityReference>(executionContext), service);
                    if (principalAccessRes.AccessRights != AccessRights.ReadAccess)
                    {
                        traceMessage += ("\n Grant the user read access to the lead.");
                        var grantAccessRequest1 = new GrantAccessRequest
                        {
                            PrincipalAccess = new PrincipalAccess
                            {
                                AccessMask = AccessRights.ReadAccess,
                                Principal = Team.Get<EntityReference>(executionContext)
                            },
                            Target = Lead.Get<EntityReference>(executionContext)
                        };
                        service.Execute(grantAccessRequest1);
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in GetAppointmentFromLead workflow: " + ex.Message.ToString());
            }

        }
        #endregion
        #region helper function
        private RetrievePrincipalAccessResponse RetrieveAndDisplayPrincipalAccess(EntityReference leadReference,
            EntityReference principal, IOrganizationService service)
        {
            var principalAccessReq = new RetrievePrincipalAccessRequest
            {
                Principal = principal,
                Target = leadReference
            };
            RetrievePrincipalAccessResponse principalAccessRes = (RetrievePrincipalAccessResponse)service.Execute(principalAccessReq);

            return principalAccessRes;
            //Console.WriteLine("Access rights of {0} ({1}) on the lead: {2}\r\n",
            //    GetEntityReferenceString(principal),
            //    additionalIdentifier,
            //    principalAccessRes.AccessRights);
        }
        #endregion
    }
}
